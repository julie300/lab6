import numpy as np
from PIL import Image
from matplotlib import pyplot as plt
im = np.array(Image.open('my_map.pgm'), dtype = 'i')
im[im==0] = 1
im[im==205] = -1
im[im==254] = 0
print(np.unique(im))
np.savetxt('mymap.csv', im, delimiter=',')
plt.matshow(im)
plt.show()